# Acode plugin

> For typescript version of plugin template switch this repo to main-ts

Read acode plugin [documentation](https://acode.foxdebug.com/plugin-docs) to develop plugin for acode editor.
